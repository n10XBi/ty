const axios = require("axios");
const vm = require('node:vm');

async function savefrom(url) {
    let body = new URLSearchParams({
        "sf_url": encodeURI(url),
        "sf_submit": "",
        "new": 2,
        "lang": "id",
        "app": "",
        "country": "id",
        "os": "Windows",
        "browser": "Chrome",
        "channel": " main",
        "sf-nomad": 1
    });
    let { data } = await axios({
        "url": "https://worker.sf-tools.com/savefrom.php",
        "method": "POST",
        "data": body,
        "headers": {
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://id.savefrom.net",
            "referer": "https://id.savefrom.net/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/99.0.4844.74 Safari/537.36"
        }
    });

    // Modifikasi skrip untuk menghindari referensi ke `window`
    const context = {
        scriptResult: "",
        i: 0,
        location: { hostname: "savefrom.net" } // Menambahkan objek `location` untuk mensimulasikan lingkungan browser
    };

    let exec = 'if (location.hostname.search(/(?:^|\\.|@)(savefrom\\.net|sfrom\\.net|ssyoutube\\.com)$/i) == -1) { throw new Error("Invalid hostname"); }';
    data = data.replace(
        'if(window.location.hostname.search(/(?:^|\\.|@)(savefrom\\.net|sfrom\\.net|ssyoutube\\.com)$/i) == -1) {',
        exec
    );

    vm.createContext(context);
    new vm.Script(data).runInContext(context);

    // Ekstraksi hasil
    const resultScript = context.scriptResult.split("window.parent.sf.videoResult.show(")?.[1]?.split(");")?.[0];
    if (!resultScript) {
        throw new Error("Failed to parse result.");
    }

    return JSON.parse(resultScript);
}

module.exports.savefrom = savefrom;
